package org.kamiblue.client.util.math

class Vec3f(val x: Float, val y: Float, val z: Float)